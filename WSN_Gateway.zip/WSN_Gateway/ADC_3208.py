import spidev
import time

spi = spidev.SpiDev() # Open SPI bus
spi.open(0, 0)
spi.max_speed_hz = 100000

def ReadChannel(channel): # read channel (0-7) from MCP3208
    adc = spi.xfer([6 | (channel & 4) >> 2, (channel & 3) << 6, 0],5,1000)
    data = ((adc[1] & 15) << 8) + adc[2]
    return data

while(True):
    for i in range(0, 7):
        print(ReadChannel(i))
    
    print("----------------------")
    print("                 ")
    time.sleep(2)