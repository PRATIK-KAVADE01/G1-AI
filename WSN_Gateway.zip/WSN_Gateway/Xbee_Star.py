import time
import paho.mqtt.client as mqtt
import json
import os
import sys
import serial

def is_json(myjson):
    try:
        json.loads(myjson)
    except ValueError as e:
        return False
    return True

THINGSBOARD_HOST = 'demo.thingsboard.io'
Token = 'Q1FtNzz1kfsju6MBclZ3'
ser = serial.Serial("/dev/ttyS0",9600)

INTERVAL=2
Valid_Json = False

next_reading = time.time() 

client = mqtt.Client()

# Set access token
client.username_pw_set(Token)

# Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
client.connect(THINGSBOARD_HOST, 1883, 60)

client.loop_start()

try:
    while True:
        sensor_data = ser.readline().strip()
        Valid_Json = is_json(sensor_data)
        
        #jdata = json.loads(sensor_data)
        #print(jdata["Soil_Temp"])
        if(Valid_Json == True):
            # Sending sensor data to ThingsBoard
            print(sensor_data)
            client.publish('v1/devices/me/telemetry',sensor_data, 1)
            sensor_data = ""
            next_reading += INTERVAL
            sleep_time = next_reading-time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
except KeyboardInterrupt:
    pass

client.loop_stop()
client.disconnect()




